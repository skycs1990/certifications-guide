<?php
/**
 * Grid Schema Setup.
 * @category  MageRocket
 * @package   MageRocket_ExamDemo
 * @author  MageRocket
 * @copyright  MageRocket 

 */
namespace MageRocket\ExamDemo\Logger;

class Logger extends \Monolog\Logger
{

}
